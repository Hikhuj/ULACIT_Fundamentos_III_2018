/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana4;

/**
 *
 * @author ulacit
 */
public class Semana4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Ejemplo1 ejemploUno = new Ejemplo1();
        
        ejemploUno.ejemplo1(40);
        
        ejemploUno.ejemplo2(40);
        
        ejemploUno.ejemplo3(6);
        
        ejemploUno.ejemplo4(5);
        
        ejemploUno.ejemplo5(7);
        
        ejemploUno.ejemplo6(2);
        
        ejemploUno.ejemplo7(2);
        
        ejemploUno.menu();
    }
    
}
