/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana9_ejerciciovectores;

/**
 *
 * @author rogerjoseulaterivera
 */
public class Semana9_Ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Persona ejercicio1 = new Persona();
        EjercicioDos ejercicio2 = new EjercicioDos();
        
        ejercicio2.llamar();
        
    }
    
}
